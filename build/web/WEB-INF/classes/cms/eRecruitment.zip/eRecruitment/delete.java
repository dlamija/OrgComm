// Decompiled by DJ v3.7.7.81 Copyright 2004 Atanas Neshkov  Date: 4/20/2007 10:18:31 AM
// Home Page : http://members.fortunecity.com/neshkov/dj.html  - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   announcement.java

package cms.eRecruitment;

import java.io.PrintStream;
import java.sql.*;
import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServletRequest;
import tvo.*;
import utilities.*;
import java.io.*;
import java.util.*;
import tvo.*;
import utilities.*;
import java.net.*;

import tvo.*;
import utilities.StorageUtil;



public class delete
{

    public delete()
    {
        conn = null;
        errorMsg = null;
    }

    public boolean deleteFiles(String s, String s1,HttpServletRequest httpservletrequest)
    {
        boolean flag = true;
        String deleteTarget = null;
        
        String s8 = "delete staff_candidate_attachment where sca_ref_id = ? and SCA_CANDIDATE_REFID = ? ";
        try
        {
            PreparedStatement preparedstatement = conn.prepareStatement(s8);
            preparedstatement.clearParameters();
            preparedstatement.setString(1, s);
            preparedstatement.setString(2, s1);
            System.out.println(s);
            System.out.println(s1);
            preparedstatement.execute();
            System.out.println("Berjaya delete");
            preparedstatement.close();
            conn.commit();
            String s2 = ("http://localhost:8888/kuktem/sites/default/recruitment/applicant/2008-114384/fileHOSTEL.txt");
            File file = new File(s2);
            file.delete();
        }
        catch(Exception exception)
        {
            flag = false;
            errorMsg = exception.toString();
        }
        return flag;
    }

    
    public String getErrorMsg()
    {
        return errorMsg;
    }

    public void setConn(Connection connection)
    {
        conn = connection;
    }

    Connection conn;
    String errorMsg;
}