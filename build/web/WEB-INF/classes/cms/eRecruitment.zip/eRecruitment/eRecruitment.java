// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 22/10/2010 3:49:59 PM
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   eRecruitment.java

package cms.eRecruitment;

import java.sql.*;

public class eRecruitment
{

    public eRecruitment()
    {
        conn = null;
        sql = null;
        errmsg = null;
    }

    public void setDBConnection(Connection connection)
    {
        conn = connection;
    }

    public String getErrorMessage()
    {
        return errmsg;
    }

    public boolean isPemohon(String s, String s1)
    {
        boolean flag = false;
        sql = "SELECT 1 from ERECRUITMENT_REGISTRATION where ER_IC_NO = upper(?) and upper(ER_PASSWORD) = upper(?) ";
        try
        {
            PreparedStatement preparedstatement = conn.prepareStatement(sql);
            preparedstatement.setString(1, s);
            preparedstatement.setString(2, s1);
            ResultSet resultset = preparedstatement.executeQuery();
            if(resultset.next())
                flag = true;
            else
                errmsg = "Not found";
            preparedstatement.close();
        }
        catch(SQLException sqlexception)
        {
            errmsg = "Error : " + sqlexception.toString();
        }
        return flag;
    }

    protected Connection conn;
    protected String sql;
    protected String errmsg;
}