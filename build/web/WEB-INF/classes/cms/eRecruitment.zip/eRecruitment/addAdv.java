// Decompiled by DJ v3.7.7.81 Copyright 2004 Atanas Neshkov  Date: 4/20/2007 10:18:31 AM
// Home Page : http://members.fortunecity.com/neshkov/dj.html  - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   announcement.java

package cms.eRecruitment;

import java.io.PrintStream;
import java.sql.*;
import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServletRequest;
import tvo.*;
import utilities.*;
import java.io.*;
import java.util.*;
import tvo.*;
import utilities.*;
import java.net.*;

import tvo.*;
import utilities.StorageUtil;



public class addAdv
{

    public addAdv()
    {
        conn = null;
        errorMsg = null;
    }

    public boolean addAdvertisment(String jenis, HttpServletRequest httpservletrequest)
    {
        boolean flag = true;
        String newsBody = httpservletrequest.getParameter("freeRTE_content").toString();
        String closing = httpservletrequest.getParameter("closing").toString();
        //String closing = "12-09-2010";
               
        String s7 = "INSERT INTO RECRUITMENT_ADVERTISMENT (RA_TYPE,RA_CLOSING_DATE) VALUES (?, TO_DATE(?,'DD-MM-YYYY')) ";
        try
        {
        	//System.out.println("masuk 1");
            PreparedStatement preparedstatement = conn.prepareStatement(s7);
            preparedstatement.setString(1, jenis);
            preparedstatement.setString(2, closing);
            //System.out.println(closing);
            preparedstatement.executeUpdate();
            QueryUtil.updateCLOB(conn, "recruitment_advertisment", "ra_content", newsBody, "ra_type ='" + jenis + "'");
            preparedstatement.close();
           //System.out.println("masuk 3");
        }
        catch(Exception exception)
        {
            flag = false;
            errorMsg = exception.toString();
        }
        return flag;
    }

     public boolean editAdvertisment(String jenis,HttpServletRequest httpservletrequest)
    {
        boolean flag = true;
        String newsBody = httpservletrequest.getParameter("freeRTE_content").toString();
        String closing = httpservletrequest.getParameter("closing").toString();

        String s7 = "UPDATE RECRUITMENT_ADVERTISMENT SET RA_CLOSING_DATE = TO_DATE(?,'DD-MM-YYYY') WHERE RA_TYPE = ? ";
        try
        {
        	//System.out.println("masuk 1 EDIT");
        	PreparedStatement preparedstatement = conn.prepareStatement(s7);
            preparedstatement.setString(1, closing);
            preparedstatement.setString(2, jenis);
            preparedstatement.executeUpdate();
            QueryUtil.updateCLOB(conn, "recruitment_advertisment", "ra_content", newsBody, "ra_type ='" + jenis + "'");
            preparedstatement.close();
            //System.out.println("masuk 2 EDIT");
        }
        catch(Exception exception)
        {
            flag = false;
            errorMsg = exception.toString();
        }
        return flag;
    }
    public String getErrorMsg()
    {
        return errorMsg;
    }

    public void setConn(Connection connection)
    {
        conn = connection;
    }

    Connection conn;
    String errorMsg;
}