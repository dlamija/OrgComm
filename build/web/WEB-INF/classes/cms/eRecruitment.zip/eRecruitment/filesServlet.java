/*
 * Created on May 11, 2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package cms.Helpdesk;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.sql.*;
import javax.sql.*;
import javax.naming.*;

/**
 * @author Taquddin
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class HelpdeskServlet extends HttpServlet
{
	private HelpdeskBean helpdesk = new HelpdeskBean ();
	private Connection conn = null;

	public void connect()
	{
		try
		{
			Context initCtx = new InitialContext();
			Context envCtx = (Context) initCtx.lookup("java:comp/env");
			DataSource ds = (DataSource) envCtx.lookup("jdbc/cmsdb");
			conn = ds.getConnection();
			helpdesk.setConn(conn);
		}
		catch (Exception e)
		{

		}
	}

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException
	{
		doPost(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException
	{
		connect();
		String action = request.getParameter("action").toString();
		// List of action
		if (action.equals("feedback"))
		{
			helpdesk.FeedBackComplain(request.getParameter("compid").toString(), request.getParameter("feedback").toString());
			//System.out.println (request.getParameter("feedback").toString());
		}
		// Close connection
		try
		{
			conn.close();
		}
		catch (Exception e)
		{
			conn = null;
		}
		// Redirect
		if (action.equals("feedback"))
			response.sendRedirect("../complaintForms.jsp?action=feedbackcomplain");
	}

}