// Decompiled by DJ v3.7.7.81 Copyright 2004 Atanas Neshkov  Date: 4/20/2007 10:28:11 AM
// Home Page : http://members.fortunecity.com/neshkov/dj.html  - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   AnnouncementServlet.java

package cms.eRecruitment;

import java.io.IOException;
import java.sql.*;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.http.*;
import javax.sql.DataSource;
import tvo.TvoDebug;

// Referenced classes of package cms.announcement:
//            announcement

public class deleteServlet extends HttpServlet
{

    public deleteServlet()
    {
        delete_File = new delete();
        conn = null;
    }

    public void connect()
    {
    	try {    	
	        InitialContext initialcontext = new InitialContext();
	        Context context = (Context)initialcontext.lookup("java:comp/env");
	        DataSource datasource = (DataSource)context.lookup("jdbc/cmsdb");
	        conn = datasource.getConnection();
	        delete_File.setConn(conn);
	  	}
	  	catch (Exception ne) {
	  		System.out.println("deleteServlet.connect():" + ne);
	  	}    
    }

    public void doGet(HttpServletRequest httpservletrequest, HttpServletResponse httpservletresponse)
        throws IOException, ServletException
    {
        doPost(httpservletrequest, httpservletresponse);
    }

    public void doPost(HttpServletRequest httpservletrequest, HttpServletResponse httpservletresponse)
        throws IOException, ServletException
    {
		String s = httpservletrequest.getParameter("action").toString();
		
		try {
	        connect();
	        
	        if(s.equals("delete"))
	            delete_File.deleteFiles(httpservletrequest.getParameter("file").toString(), httpservletrequest.getParameter("ref_id").toString(), httpservletrequest);
		}
		catch (Exception e) {
			System.out.println("deleteServlet.doPost():" + e);
            TvoDebug.printStackTrace(e);
		}
		finally {
			try {			
				if (conn != null) conn.close();	
			}
			catch (SQLException sqle) { }
		}
		
        if(s.equals("delete"))
            httpservletresponse.sendRedirect("../eRecruitment.jsp?action=upload&refid=2008-114384 ");
    }

    private delete delete_File;
    private Connection conn;
}