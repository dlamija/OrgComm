// Decompiled by DJ v3.7.7.81 Copyright 2004 Atanas Neshkov  Date: 4/20/2007 10:28:11 AM
// Home Page : http://members.fortunecity.com/neshkov/dj.html  - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   AnnouncementServlet.java

package cms.eRecruitment;

import java.io.IOException;
import java.sql.*;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.http.*;
import javax.sql.DataSource;
import tvo.TvoDebug;

// Referenced classes of package cms.announcement:
//            announcement

public class advServlet extends HttpServlet
{

    public advServlet()
    {
        addAdv = new addAdv();
        conn = null;
    }

    public void connect()
    {
    	try {    	
	        InitialContext initialcontext = new InitialContext();
	        Context context = (Context)initialcontext.lookup("java:comp/env");
	        DataSource datasource = (DataSource)context.lookup("jdbc/cmsdb");
	        conn = datasource.getConnection();
	        addAdv.setConn(conn);
	  	}
	  	catch (Exception ne) {
	  		System.out.println("advServlet.connect():" + ne);
	  	}    
    }

    public void doGet(HttpServletRequest httpservletrequest, HttpServletResponse httpservletresponse)
        throws IOException, ServletException
    {
        doPost(httpservletrequest, httpservletresponse);
    }

    public void doPost(HttpServletRequest httpservletrequest, HttpServletResponse httpservletresponse)
        throws IOException, ServletException
    {
		String s = httpservletrequest.getParameter("action").toString();
		
		try {
	        connect();
	        
	        if(s.equals("add"))
	            addAdv.addAdvertisment(httpservletrequest.getParameter("jenis").toString(), httpservletrequest);
	        if(s.equals("edit"))
	            addAdv.editAdvertisment(httpservletrequest.getParameter("jenis").toString(), httpservletrequest);
		}
		catch (Exception e) {
			System.out.println("advServlet.doPost():" + e);
            TvoDebug.printStackTrace(e);
		}
		finally {
			try {			
				if (conn != null) conn.close();	
			}
			catch (SQLException sqle) { }
		}
		
        if(s.equals("add"))
            httpservletresponse.sendRedirect("../eRecruitment.jsp?action=main_admin&jenis="+ httpservletrequest.getParameter("jenis").toString() );
        else
        if(s.equals("edit"))
            httpservletresponse.sendRedirect("../eRecruitment.jsp?action=main_admin&jenis="+ httpservletrequest.getParameter("jenis").toString() );
    }

    private addAdv addAdv;
    private Connection conn;
}